var filesystem = require('fs');
const path = require('path');
const Base64 = require('js-base64');
const uploadImageFromBase64 = (imgBase64, imageName) => {
    var base64Data = imgBase64.replace(/^data:image\/\w+;base64,/, "");
    filesystem.writeFile(imageName, base64Data, 'base64', function(err) {
        console.log(`Image uploaded.`);
        return false;
    });
    return true;
}

const uploadXlsxFromBase64 = (Base64Code, xlsxName) => {
    filesystem.writeFile(xlsxName, Base64Code, 'base64', function(err) {
        console.log(`Xlsx uploaded.`);
        return false;
    })
    return true;
}

const uploadPdfFromBase64 = (Base64Code, pdfName) => {
    var bin = Base64.atob(Base64Code);
    // Your code to handle binary data
    filesystem.writeFile(pdfName, bin, 'binary', error => {
        if (error) {
            throw error;
        } else {
            console.log('PDF uploaded.');
        }
    });
    return true;
}

const uploadFileFromBase64 = (Base64Code, filename) => {
    filesystem.writeFile(filename, Base64Code, 'base64', function(err) {
        console.log(`File uploaded.`);
        return false;
    })
    return true;
}
module.exports = {
    uploadImageFromBase64,
    uploadXlsxFromBase64,
    uploadPdfFromBase64,
    uploadFileFromBase64
}