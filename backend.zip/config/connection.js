// const sql = require('mssql');
const mysql = require('mysql2/promise');
const { Sequelize } = require('sequelize');

module.exports = db = {};

initialize();

async function initialize() {
    // create db if it doesn't already exist
    var host = process.env.DB_HOST || "127.0.0.1";
    var port = process.env.DB_PORT || 3306;
    var database = process.env.DB_DATABASE || "techathon";
    var user = process.env.DB_USERNAME || "root";
    var password = process.env.DB_PASSWORD || "";
    const connection = await mysql.createConnection({ host, port, user, password });
    await connection.query(`CREATE DATABASE IF NOT EXISTS \`${database}\`;`);

    // connect to db
    const sequelize = new Sequelize(database, user, password, { dialect: 'mysql' });

    // init models and add them to the exported db object
    db.User = require('../models/user')(sequelize);
    db.Document = require('../models/document')(sequelize);

    db.Document.belongsTo(db.User, {
        foreignKey: 'user_id'
    });
    // sync all models with database
    await sequelize.sync();

}