const jwt = require('jsonwebtoken');
const bcrypt = require('bcryptjs');
const db = require('../config/connection');
const Op = require('sequelize').Op;
const helper = require('../helper/uploadImage');
const reader =require('xlsx');

module.exports = {
    authenticate,
    getAll,
    getById,
    getUserWithDetails,
    studentCheck,
    editUser,
    dashboard,
    create,
    update,
    uploadFile,
    delete: _delete,
};

async function authenticate({ email, password, user_type }) {
    const user = await db.User.scope('withPassword').findOne({ where: { 
        [Op.or]: [{email: email}, {ins_id: email}], user_type } });

    if (!user || !(await bcrypt.compare(password, user.password))) {
        let msg = 'Email or password is incorrect';
        return { 'status': 400, 'msg': msg };
    }
    
    // authentication successful
    const token = jwt.sign({ sub: user.id }, process.env.TOKEN_KEY, { expiresIn: '24h' });
    var status = 200;
    return {...omitHash(user.get()), token, status };
}


async function getAll(id) {
    var data = await db.User.findAll({
        where: {
            user_type: 3,
            id : {
                [Op.ne]:id
            }
        },
        attributes: [
            "id", "name"
        ]
    });
    return {"status":200, "msg":"list fetched.", "data":data};
}

async function getById(id) {
    return await getUser(id);
}

async function create(params) {
    // validate

    if (await db.User.findOne({ where: { email: params.email } })) {
        let msg = 'Email "' + params.email + '" is already taken';
        return { 'status': 400, 'msg': msg };
    }
    // hash password
    if (params.password) {
        params.password = await bcrypt.hash(params.password, 10);
    }
    params.user_type = 2;
    params.create_by = 1;
    // save user
    await db.User.create(params);
    return { 'status': 200, 'msg': "Register Successfully." };
}

async function studentCheck(params) {
    // validate
    if (await db.User.findOne({ where: {
            [Op.or]: [{email: params.email}, {ins_id: params.ins_id}]
        } })) {
        let msg = 'Email/Institute Id "' + params.email + ' / "'+params.ins_id+'" is already exist.';
        return { 'status': 400, 'msg': msg };
    }
    // hash password
    if (params.password) {
        params.password = await bcrypt.hash(params.password, 10);
    }
    params.user_type = 3;
    params.create_by = 1;
    // save user
    await db.User.create(params);
    return { 'status': 200, 'msg': "Register Successfully." };
}

async function update(id, params) {
    const user = await db.User.findByPk(id);
    // validate
    const usernameChanged = params.email && user.email !== params.email;
    if (usernameChanged && await db.User.findOne({ where: { email: params.email } })) {
        let msg = 'Email "' + params.email + '" is already taken';
        return { 'status': 400, 'msg': msg };
    }

    // hash password if it was entered
    if (params.password !== undefined && params.password !== null && params.password !== "") {
        params.password = await bcrypt.hash(params.password, 10);
    } else {
        delete params.password
    }
    if (params.organization_id !== '') {
        params.organization_id = parseInt(params.organization_id);
    }
    // copy params to user and save
    Object.assign(user, params);
    await user.save();

    return { 'status': 200, 'msg': "User update Successfully." };
}

async function _delete(id) {
    const user = await getUser(id);
    await user.destroy();
}

// helper functions

async function getUser(id) {
    const user = await db.User.findByPk(id);
    if (!user) throw 'User not found';
    const token = jwt.sign({ sub: user.id }, process.env.TOKEN_KEY, { expiresIn: '2h' });
    return {...omitHash(user.get()), token };
}

async function editUser(id) {
    const user = await db.User.findByPk(id);
    var res = {
        id: user.id,
        email: user.email,
        organization_id: user.organization_id,
        status: user.status
    }
    return res;
}

async function getUserWithDetails(id) {
    const user = await db.User.findOne({
        where: {
            id: id
        },
        attributes: ['id', "name", "email", "mobile"],
        include: [{
                model: db.Organization,
                attributes: ["name", "phone_1", "address_1", "address_2"]
            },
            {
                model: db.Branch,
                attributes: [
                    "id", "name"
                ],
                include: {
                    model: db.BranchService,
                    attributes: ["services"]
                }
            },
            {
                model: db.QueueProcess,
                attributes: ["id"],
                include: {
                    model: db.Counter,
                    attributes: ["name"]
                }
            }
        ]
    });
    return user;
}

function omitHash(user) {
    const { hash, ...userWithoutHash } = user;
    return userWithoutHash;
}

async function dashboard(data) {
    var user = await getUser(data.id);
    return user;
}

async function uploadFile(data) {
    var imageName = './public/file/'+data.name;
    if(data.image != "")
    {
        // await helper.uploadXlsxFromBase64(data.image, imageName);
        const file = reader.readFile(imageName);
        const sheets = file.SheetNames;
        for(let i = 0; i < sheets.length; i++)
        {
            const temp = reader.utils.sheet_to_json(
                file.Sheets[file.SheetNames[i]]
            );
            temp.forEach(async (res) => {
                db.User.create({
                    user_type: 3,
                    name : res.Name,
                    ins_id : res['Institute ID'],
                    email : res.Email,
                    password : await bcrypt.hash(`${res.Password}`, 10)
                });
            });
        }
        return {"status":200, "msg":"Data Uploaded."};
    }
}