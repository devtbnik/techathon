const db = require('../config/connection');
const helper = require('../helper/uploadImage');
const fs = require('fs');
module.exports = {
    getAll,
    getAllUser,
    getById,
    create,
    update,
    delete: _delete
};



async function getAll() {
    var data = await db.Document.findAll({
        where : {
            public : true,
        },
        include : [{
            model : db.User,
            attributes: ["name"]
        }]
    });
    if(data.length > 0){
        var links = {
            image : [],
            pdf : [],
            video : []
        };
        var baseUrl = process.env.APP_URL;
        data.map(i =>{
            var url = baseUrl+i.path+"/"+i.name;
            var name = i.user.name;
            var arr = {
                url : url,
                name : name
            }
            if(i.type == "image"){
                links.image.push(arr);
            } else if(i.type == "pdf"){
                arr.pdfimg = baseUrl+"/public/pdfimg.png";
                links.pdf.push(arr)
            } else if(i.type == "video"){
                links.video.push(arr)
            }
        })
        return {"status": 200, "msg":"data fetch.", "data":links}
    }
    return {"status": 400, "msg":"no one shared file with you."};
}

async function getAllUser(id) {
    var data = await db.Document.findAll({
        where : {
            public : false,
            receiver_user_id : id
        },
        include : [{
            model : db.User,
            attributes: ["name"]
        }]
    });
    if(data.length > 0){
        var links = {
            image : [],
            pdf : [],
            video : []
        };
        var baseUrl = process.env.APP_URL;
        data.map(i =>{
            var url = baseUrl+i.path+"/"+i.name;
            var name = i.user.name;
            var arr = {
                url : url,
                name : name
            }
            if(i.type == "image"){
                links.image.push(arr);
            } else if(i.type == "pdf"){
                arr.pdfimg = baseUrl+"/public/pdfimg.png";
                links.pdf.push(arr)
            } else if(i.type == "video"){
                links.video.push(arr)
            }
        })
        return {"status": 200, "msg":"data fetch.", "data":links}
    }
    return {"status": 400, "msg":"no data found."};
}

async function getById(id) {
    return await getOrganization(id);
}

async function create(params) {
    // validate
    if(params.file !== ""){
        var base64Code = params.file;
        var filename = params.name;
        var path = "./public/file/"+params.user_id;
        var dbPath = "/public/file/"+params.user_id;
        if (!fs.existsSync(path)){
            fs.mkdirSync(path);
        }
        if(params.file_type == "pdf"){
            await helper.uploadPdfFromBase64(base64Code, path+"/"+filename);
        } else {
            await helper.uploadFileFromBase64(base64Code, path+"/"+filename);
        }
        var docData;
        if(params.public){
            docData = {
                user_id: params.user_id,
                name:filename,
                path: dbPath,
                public:true,
                type : params.file_type
            }
            await db.Document.create(docData);
            return {'status': 200, 'msg' : "Document shared success."};
        } else {
            if(params.to_user.length > 0){
                params.to_user.map(async (i) => {
                    docData = {
                        user_id: params.user_id,
                        name:filename,
                        path: path,
                        public:false,
                        receiver_user_id : i,
                        type : params.file_type
                    }
                    await db.Document.create(docData);
                })
                return {'status': 200, 'msg' : "Document shared success."};
            }
        }
    }
    return {'status': 400, 'msg' : "something went wrong"};
}

async function update(id, params) {
    const organization = await getOrganization(id);

    // validate
    const nameChanged = params.name && organization.name !== params.name;
    const emailChanged = params.email && organization.email !== params.email;
    const phoneChanged = params.phone_1 && organization.phone_1 !== params.phone_1;
    if (emailChanged && await db.Organization.findOne({ where: { email: params.email } })) {
        throw 'Email "' + params.email + '" is already taken';
    }
    if (nameChanged && await db.Organization.findOne({ where: { name: params.name } })) {
        let msg = 'Organization name already exist';
        return {'status': 400, 'msg' : msg};
    }
    if (phoneChanged && await db.Organization.findOne({ where: { phone_1: params.phone_1 } })) {
        let msg = 'Mobile already exist';
        return {'status': 400, 'msg' : msg};
    }

    if('image' in params && params.image !== null && organization.image !== params.image){
        let imgName = Date.now().toString()+".png";
        let path = "./public/images/";
        if(helper.uploadImageFromBase64(params.image, path+imgName)){
            params.image = imgName;
            fs.unlink(path+organization.image, (res) => {
                console.log("delete");
            });
        } else {
            params.image = null;
        }
    }

    // copy params to Organization and save
    Object.assign(organization, params);
    await organization.save();

    return {'status': 200, 'msg' : "Organization update Successfully."};
}

async function _delete(id) {
    const organization = await getOrganization(id);
    await organization.destroy();
}

// helper functions

async function getOrganization(id) {
    const organization = await db.Organization.findByPk(id);
    if (!organization) throw 'Organization not found';
    return organization;
}