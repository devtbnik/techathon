var express = require('express');
const userCon = require('../controllers/user_controller');
const docCon = require('../controllers/document_controller');
const auth = require("../middleware/auth");
var router = express.Router();

/* GET users listing. */

router.post("/signup", async(req, res, next) => {
    var data = req.body;
    await userCon.studentCheck(data)
        .then((data) => res.json(data))
        .catch(next);
});

router.post("/login", async(req, res, next) => {
    await userCon.authenticate(req.body)
        .then(user => res.json(user))
        .catch(next);
});

router.post("/dashboard", auth, async(req, res, next) => {
    await userCon.dashboard(req.body)
        .then(data => res.json(data))
        .catch(next);
});

router.post("/upload-file", async(req, res, next) => {
    await userCon.uploadFile(req.body)
        .then(data => res.json(data))
        .catch(next);
});

router.get("/getuser/:id", auth, async(req, res, next) => {
    await userCon.getById(req.params.id)
        .then(data => res.json(data))
        .catch(next);
});

router.get("/edit-user/:id", auth, async(req, res, next) => {
    await userCon.editUser(req.params.id)
        .then(data => res.json(data))
        .catch(next);
});

router.get("/all-user", auth, async(req, res, next) => {
    await userCon.getAll(req.user.sub)
        .then(data => res.json(data))
        .catch(next);
});

router.post("/add-user", auth, async(req, res, next) => {
    var data = req.body;
    await userCon.create(data)
        .then((data) => res.json(data))
        .catch(next);
});

router.post("/update-user/:id", auth, async(req, res, next) => {
    await userCon.update(req.params.id, req.body)
        .then(data => res.json(data))
        .catch(next);
});

router.get("/all-public-doc", auth, async(req, res, next) => {
    await docCon.getAll()
        .then(data => res.json(data))
        .catch(next);
});

router.get("/all-users-doc", auth, async(req, res, next) => {
    await docCon.getAllUser(req.user.sub)
        .then(data => res.json(data))
        .catch(next);
});

router.post("/add-document", auth, async(req, res, next) => {
    var data = req.body;
    data.user_id = req.user.sub;
    await docCon.create(data)
        .then((data) => res.json(data))
        .catch(next);
});

router.get("/get-organization/:id", auth, async(req, res, next) => {
    await docCon.getById(req.params.id)
        .then(data => res.json(data))
        .catch(next);
});

router.post("/update-organization/:id", auth, async(req, res, next) => {
    await docCon.update(req.params.id, req.body)
        .then(data => res.json(data))
        .catch(next);
});
module.exports = router;