const { DataTypes } = require('sequelize');

module.exports = model;

function model(sequelize) {
    const attributes = {
        id: {
            type: DataTypes.INTEGER, 
            primaryKey: true, 
            autoIncrement: true
        },
        user_type : { 
            type: DataTypes.INTEGER, 
            allowNull : false
        },
        name: { 
            type: DataTypes.STRING, 
            allowNull : true
        },
        ins_id: { 
            type: DataTypes.STRING, 
            allowNull : true
        },
        email: { 
            type: DataTypes.STRING, 
            allowNull : false
        },
        password: { 
            type: DataTypes.STRING, 
            allowNull : false
        },
        create_by: { 
            type: DataTypes.TINYINT, 
            allowNull : false, defaultValue:0
        },
        status : {
            type: DataTypes.TINYINT,
            defaultValue:0
        }
    };

    const options = {
        underscore: true,
        defaultScope: {
            // exclude hash by default
            attributes: { exclude: ['password'] }
        },
        scopes: {
            // include hash with this scope
            withPassword: { attributes: {}, }
        }
    };
    return sequelize.define('user', attributes, options);
}