const { DataTypes } = require('sequelize');

module.exports = model;

function model(sequelize) {
    const attributes = {
        id: {
            type: DataTypes.INTEGER, 
            primaryKey: true, 
            autoIncrement: true
        },
        user_id: {
            type: DataTypes.TINYINT, 
            allowNull : false
        },
        name : { 
            type: DataTypes.STRING, 
            allowNull : false
        },
        path: { 
            type: DataTypes.STRING, 
            allowNull : false
        },
        receiver_user_id: {
            type: DataTypes.TINYINT, 
            allowNull : true
        },
        public: {
            type: DataTypes.BOOLEAN, 
            allowNull : false,
            defaultValue:false
        },
        type: {
            type: DataTypes.STRING,
            allowNull: false
        }
    };

    const options = {
        underscore: true,
        timestamps: true,
    };

    return sequelize.define('document', attributes, options);
}